#include <iostream>
using namespace std;

main()
{
  int x, y;                           // declarations
  double a, b, c, d;
  x=2; y=4;                           // Affectations
  a=x+y; b=x-y; c=x*y; d=x/y;         // Operations
                                      // Affichage des resultats
  cout << " 2+4=" << a << " 2-4=" << b
       << " 2*4=" << c << " 2/4=" << d << endl;
}
